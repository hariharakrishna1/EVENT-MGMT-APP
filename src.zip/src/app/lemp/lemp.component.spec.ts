import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LempComponent } from './lemp.component';

describe('LempComponent', () => {
  let component: LempComponent;
  let fixture: ComponentFixture<LempComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LempComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
