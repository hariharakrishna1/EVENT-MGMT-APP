import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { Employee } from './lemp.model';
@Component({
  selector: 'app-lemp',
  templateUrl: './lemp.component.html',
  styleUrls: ['./lemp.component.css']
})
export class LempComponent implements OnInit {

  formvalue!:FormGroup
  empobj:Employee=new Employee();
  empdata!:any;
  constructor(private fb:FormBuilder,private api:ApiService) { }

  ngOnInit(): void {
    this.formvalue=this.fb.group({
      name:[''],
      email:[''],
      mobile:[''],
      id:[''],
    })
    this.getemploy()
  }
postemploy()
{
  this.empobj.name=this.formvalue.value.name;
  this.empobj.email=this.formvalue.value.email;
  this.empobj.mobile=this.formvalue.value.mobile;
  
  this.api.postemploy(this.empobj).subscribe(res=>{
    console.log(res);
    alert("RECORD ADDED")
    let ref=document.getElementById('cancel')
    ref?.click();
    this.formvalue.reset();
    this.getemploy();
  },
  err=>{alert("TRY AGAIN")
  })
}

getemploy(){
  this.api.getemploy().subscribe(res=>{
    this.empdata=res;
  })
}

delemploy(e:any)
{
  this.api.deleteemploy(e.id).subscribe(res=>{
    alert("Student record deleted")
    this.getemploy()
  })
}
editemploy(e:any)
{
  this.empobj.id=e.id;
this.formvalue.controls['name'].setValue(e.name);
this.formvalue.controls['email'].setValue(e.email);
this.formvalue.controls['mobile'].setValue(e.mobile);
}
updateemploy()
{
  this.empobj.name=this.formvalue.value.name;
  this.empobj.email=this.formvalue.value.email;
  this.empobj.mobile=this.formvalue.value.mobile;

  this.api.updatemploy(this.empobj, this.empobj.id).subscribe(res=>{
    alert("Updated")
    let ref=document.getElementById('cancel')
    ref?.click();
    this.formvalue.reset();
    this.getemploy();
  })
}
}