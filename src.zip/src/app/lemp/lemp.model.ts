export class Employee
{
    id:number=0;
    name:string='';
    email:string='';
    mobile:number=0;
}