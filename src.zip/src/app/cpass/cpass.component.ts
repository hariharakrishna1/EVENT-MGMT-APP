import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpass',
  templateUrl: './cpass.component.html',
  styleUrls: ['./cpass.component.css']
})
export class CpassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
